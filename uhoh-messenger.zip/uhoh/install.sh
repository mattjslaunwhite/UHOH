#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sudo dnf install -y python3 python3-pip python3-pyqt6 qt6-qtwebsockets qt6-qtwayland \
     python3-websockets pipewire-utils libnotify gnome-shell-extension-appindicator
VENV="$HOME/.local/share/uhoh-venv"
python3 -m venv --system-site-packages "$VENV"
"$VENV/bin/pip" install .
mkdir -p ~/.local/share/applications ~/.config/systemd/user
sed "s|@VENV@|$VENV|g" packaging/uhoh.desktop.in > ~/.local/share/applications/uhoh.desktop
sed "s|@VENV@|$VENV|g" packaging/uhoh-server.service.in > ~/.config/systemd/user/uhoh-server.service
update-desktop-database ~/.local/share/applications 2>/dev/null || true
systemctl --user daemon-reload
systemctl --user enable --now uhoh-server.service
gnome-extensions enable appindicatorsupport@rgcjonas.gmail.com 2>/dev/null || true
echo "Done. Launch 'UhOh! Messenger' from Activities, or run: $VENV/bin/uhoh"
echo "(Log out/in once if the tray-icon extension was just installed.)"
