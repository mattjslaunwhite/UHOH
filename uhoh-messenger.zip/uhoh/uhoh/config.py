import json
import os
from pathlib import Path

APP = "uhoh"
_home = Path.home()
CONFIG_DIR = Path(os.environ.get("XDG_CONFIG_HOME", _home / ".config")) / APP
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", _home / ".local/share")) / APP
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME", _home / ".cache")) / APP

DEFAULTS = {
    "server": "ws://127.0.0.1:8765",
    "uin": "",
    "color": "#0000aa",
    "sounds": True,
}


def load() -> dict:
    try:
        data = json.loads((CONFIG_DIR / "config.json").read_text())
    except Exception:
        data = {}
    return {**DEFAULTS, **data}


def save(cfg: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    (CONFIG_DIR / "config.json").write_text(json.dumps(cfg, indent=2))
