import shutil
import subprocess


def notify(title: str, body: str, icon: str = "dialog-information") -> None:
    """Freedesktop notification via libnotify's notify-send."""
    exe = shutil.which("notify-send")
    if exe:
        subprocess.Popen([exe, "-a", "UhOh!", "-i", icon, "--", title, body])
