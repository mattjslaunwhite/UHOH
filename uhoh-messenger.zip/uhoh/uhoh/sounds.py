"""Synthesises retro sound effects (no binary assets needed) and plays them
through PipeWire (pw-play), falling back to PulseAudio/ALSA."""
import math
import shutil
import struct
import subprocess
import wave

from .config import CACHE_DIR

SOUNDS = {
    "uhoh":   [(659, .13), (494, .24)],          # incoming message
    "sent":   [(880, .06)],
    "online": [(523, .08), (659, .08), (784, .14)],
    "knock":  [(180, .05), (0, .07), (180, .05)],
}
enabled = True


def _synth(path, notes, rate=22050, vol=0.4):
    frames = bytearray()
    for freq, dur in notes:
        n = int(rate * dur)
        for i in range(n):
            env = min(1.0, i / 200, (n - i) / 400)
            s = math.sin(2 * math.pi * freq * i / rate)
            s += 0.3 * math.sin(4 * math.pi * freq * i / rate)
            frames += struct.pack("<h", int(max(-1, min(1, s * vol * env)) * 32767))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(bytes(frames))


def _ensure(name):
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    p = CACHE_DIR / f"{name}.wav"
    if not p.exists():
        _synth(p, SOUNDS[name])
    return p


def play(name: str) -> None:
    if not enabled or name not in SOUNDS:
        return
    path = _ensure(name)
    for exe, args in (("pw-play", []), ("paplay", []), ("aplay", ["-q"])):
        found = shutil.which(exe)
        if found:
            subprocess.Popen([found, *args, str(path)],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
