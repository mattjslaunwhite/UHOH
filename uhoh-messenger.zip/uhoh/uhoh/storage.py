import sqlite3
import time

from .config import DATA_DIR


class Store:
    """Per-account local SQLite storage for contacts and chat history."""

    def __init__(self, uin: str):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(DATA_DIR / f"{uin}.db")
        self.db.executescript("""
            create table if not exists contacts(uin text primary key, nick text);
            create table if not exists messages(
                id integer primary key autoincrement,
                peer text, outgoing integer, text text, color text, ts real);
            create index if not exists ix_msg on messages(peer, ts);
        """)

    def upsert_contact(self, uin: str, nick: str) -> None:
        self.db.execute("insert or replace into contacts values(?,?)", (uin, nick))
        self.db.commit()

    def add_message(self, peer, outgoing, text, color, ts=None) -> None:
        self.db.execute(
            "insert into messages(peer,outgoing,text,color,ts) values(?,?,?,?,?)",
            (peer, int(outgoing), text, color, ts or time.time()))
        self.db.commit()

    def history(self, peer: str, limit: int = 30):
        rows = self.db.execute(
            "select outgoing,text,color,ts from messages where peer=? "
            "order by ts desc limit ?", (peer, limit)).fetchall()
        return list(reversed(rows))
