import html
from datetime import datetime

from PyQt6.QtCore import QEvent, Qt, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (QColorDialog, QHBoxLayout, QPushButton, QTextBrowser,
                             QTextEdit, QVBoxLayout, QWidget)


class ChatWindow(QWidget):
    send_requested = pyqtSignal(str, str, str)   # uin, text, color

    def __init__(self, uin: str, nick: str, my_nick: str, color: str):
        super().__init__()
        self.uin, self.nick, self.my_nick, self.color = uin, nick, my_nick, color
        self.setWindowTitle(f"Message session with {nick} ({uin})")
        self.resize(380, 380)

        self.log = QTextBrowser()
        self.log.setOpenExternalLinks(True)
        self.input = QTextEdit()
        self.input.setFixedHeight(70)
        self.input.installEventFilter(self)

        color_btn = QPushButton("Color")
        color_btn.clicked.connect(self._pick_color)
        send = QPushButton("Send")
        send.clicked.connect(self._send)
        row = QHBoxLayout()
        row.addWidget(color_btn)
        row.addStretch(1)
        row.addWidget(send)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.addWidget(self.log, 1)
        lay.addWidget(self.input)
        lay.addLayout(row)
        self._paint()

    def _paint(self):
        self.input.setStyleSheet(f"color:{self.color};")

    def _pick_color(self):
        c = QColorDialog.getColor(QColor(self.color), self, "Font color")
        if c.isValid():
            self.color = c.name()
            self._paint()

    def eventFilter(self, obj, ev):
        if (obj is self.input and ev.type() == QEvent.Type.KeyPress
                and ev.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter)
                and not ev.modifiers() & Qt.KeyboardModifier.ShiftModifier):
            self._send()
            return True
        return super().eventFilter(obj, ev)

    def _send(self):
        text = self.input.toPlainText().strip()
        if text:
            self.input.clear()
            self.send_requested.emit(self.uin, text, self.color)

    def add_line(self, mine: bool, text: str, color: str, ts: float):
        stamp = datetime.fromtimestamp(ts).strftime("%H:%M:%S")
        who = self.my_nick if mine else self.nick
        name_col = "#cc0000" if mine else "#0000cc"
        body = html.escape(text).replace("\n", "<br>")
        self.log.append(
            f'<span style="color:#808080">({stamp})</span> '
            f'<b style="color:{name_col}">{html.escape(who)}:</b> '
            f'<span style="color:{color}">{body}</span>')

    def closeEvent(self, e):
        e.ignore()
        self.hide()
