from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (QHBoxLayout, QLabel, QMenu, QPushButton,
                             QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from .theme import STATUS, flower


class ContactList(QWidget):
    open_chat = pyqtSignal(str)
    status_changed = pyqtSignal(str)
    add_requested = pyqtSignal()
    quit_requested = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle("UhOh!")
        self.resize(220, 480)
        self.contacts: dict[str, dict] = {}
        self.unread: set[str] = set()

        self.banner = QLabel("UhOh!  Messenger")
        self.banner.setObjectName("banner")
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemActivated.connect(self._activated)
        self.tree.itemDoubleClicked.connect(self._activated)

        self.status_btn = QPushButton("Online")
        menu = QMenu(self)
        for key in ("online", "away", "na", "offline"):
            act = menu.addAction(flower(key), STATUS[key][0])
            act.triggered.connect(lambda _=False, k=key: self.status_changed.emit(k))
        menu.addSeparator()
        menu.addAction("Quit").triggered.connect(self.quit_requested.emit)
        self.status_btn.setMenu(menu)
        self.status_btn.setIcon(flower("online"))

        add = QPushButton("Add/Find Users")
        add.clicked.connect(self.add_requested.emit)
        row = QHBoxLayout()
        row.addWidget(self.status_btn)
        row.addWidget(add)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.addWidget(self.banner)
        lay.addWidget(self.tree, 1)
        lay.addLayout(row)

    # -- model -------------------------------------------------------------
    def set_me(self, nick: str, uin: str):
        self.banner.setText(f"{nick}  ({uin})")

    def set_my_status(self, key: str):
        self.status_btn.setText(STATUS[key][0])
        self.status_btn.setIcon(flower(key))

    def set_contacts(self, items):
        self.contacts = {c["uin"]: dict(c) for c in items}
        self.refresh()

    def upsert(self, uin, nick=None, status=None):
        c = self.contacts.setdefault(uin, {"uin": uin, "nick": uin, "status": "offline"})
        if nick:
            c["nick"] = nick
        if status:
            c["status"] = status
        self.refresh()

    def set_unread(self, uin, flag: bool):
        (self.unread.add if flag else self.unread.discard)(uin)
        self.refresh()

    def refresh(self):
        self.tree.clear()
        on, off = QTreeWidgetItem(self.tree), QTreeWidgetItem(self.tree)
        for uin, c in sorted(self.contacts.items(), key=lambda kv: kv[1]["nick"].lower()):
            grp = off if c["status"] == "offline" else on
            mark = "\u2709 " if uin in self.unread else ""
            it = QTreeWidgetItem(grp, [mark + c["nick"]])
            it.setIcon(0, flower(c["status"]))
            it.setData(0, Qt.ItemDataRole.UserRole, uin)
        on.setText(0, f"Online ({on.childCount()})")
        off.setText(0, f"Offline ({off.childCount()})")
        self.tree.expandAll()

    def _activated(self, item, _col=0):
        uin = item.data(0, Qt.ItemDataRole.UserRole)
        if uin:
            self.open_chat.emit(uin)

    def closeEvent(self, e):          # keep running in the tray
        e.ignore()
        self.hide()
