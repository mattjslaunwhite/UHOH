import math

from PyQt6.QtCore import QPointF, Qt
from PyQt6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap

STATUS = {
    "online":  ("Online",  "#2eb82e"),   # green flower
    "away":    ("Away",    "#e6c800"),   # yellow flower
    "na":      ("N/A",     "#e67e00"),   # orange flower
    "offline": ("Offline", "#cc2222"),   # red flower
}
_cache: dict = {}


def flower(status_or_color: str, size: int = 16) -> QIcon:
    color = STATUS.get(status_or_color, (None, status_or_color))[1]
    key = (color, size)
    if key in _cache:
        return _cache[key]
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c, r = size / 2, size * 0.22
    p.setPen(QPen(QColor("#303030"), 0.8))
    p.setBrush(QColor(color))
    for i in range(5):
        a = math.radians(i * 72 - 90)
        p.drawEllipse(QPointF(c + math.cos(a) * size * .27,
                              c + math.sin(a) * size * .27), r, r)
    p.setBrush(QColor("#ffffff"))
    p.drawEllipse(QPointF(c, c), size * .12, size * .12)
    p.end()
    _cache[key] = QIcon(pm)
    return _cache[key]


QSS = """
QWidget { background:#c0c0c0; color:#000; font-family:"Tahoma","DejaVu Sans"; font-size:9pt; }
QLabel#banner { background:#2e7d32; color:#fff; font-weight:bold; padding:4px; }
QTreeWidget, QTextBrowser, QTextEdit, QLineEdit {
    background:#fff; border:2px inset #808080; }
QTreeWidget::item:selected { background:#2e7d32; color:#fff; }
QPushButton { background:#c0c0c0; border:2px outset #f4f4f4; padding:3px 10px; }
QPushButton:pressed { border:2px inset #808080; }
QMenu { background:#c0c0c0; border:1px solid #404040; }
QMenu::item:selected { background:#2e7d32; color:#fff; }
"""
