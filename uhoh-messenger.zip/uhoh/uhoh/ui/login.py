from PyQt6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QFormLayout,
                             QLabel, QLineEdit, QVBoxLayout)


class LoginDialog(QDialog):
    def __init__(self, cfg: dict):
        super().__init__()
        self.setWindowTitle("UhOh! - Sign in")
        banner = QLabel("Welcome to UhOh!")
        banner.setObjectName("banner")
        self.server = QLineEdit(cfg["server"])
        self.uin = QLineEdit(cfg["uin"])
        self.uin.setPlaceholderText("e.g. 100001")
        self.pw = QLineEdit()
        self.pw.setEchoMode(QLineEdit.EchoMode.Password)
        self.new = QCheckBox("I'm new - register a UIN")
        self.nick = QLineEdit()
        self.nick.setPlaceholderText("Nickname (new accounts)")
        self.nick.setEnabled(False)
        self.new.toggled.connect(self.nick.setEnabled)
        self.new.toggled.connect(lambda on: self.uin.setEnabled(not on))

        form = QFormLayout()
        form.addRow("Server:", self.server)
        form.addRow("UIN:", self.uin)
        form.addRow("Password:", self.pw)
        form.addRow(self.new)
        form.addRow("Nick:", self.nick)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addWidget(banner)
        lay.addLayout(form)
        lay.addWidget(bb)

    def values(self) -> dict:
        return dict(server=self.server.text().strip(), uin=self.uin.text().strip(),
                    password=self.pw.text(), register=self.new.isChecked(),
                    nick=self.nick.text().strip())
