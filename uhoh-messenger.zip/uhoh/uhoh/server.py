"""Tiny self-hosted UhOh! server: numeric UINs, contacts, presence,
offline message queue. SQLite + asyncio + websockets."""
import argparse
import asyncio
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
from pathlib import Path

import websockets

DB_PATH = Path(os.environ.get("UHOH_DB", Path.home() / ".local/share/uhoh/server.db"))
COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
online: dict = {}          # uin -> (websocket, status)
conn: sqlite3.Connection


def init_db():
    global conn
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        create table if not exists users(uin integer primary key, nick text,
                                         salt blob, pw blob);
        create table if not exists contacts(owner integer, contact integer,
                                            primary key(owner, contact));
        create table if not exists offline(id integer primary key autoincrement,
            to_uin integer, from_uin integer, text text, color text, ts real);
    """)


def _hash(password: str, salt: bytes) -> bytes:
    return hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1)


async def send(ws, obj):
    try:
        await ws.send(json.dumps(obj))
    except Exception:
        pass


def status_of(uin: int) -> str:
    return online[uin][1] if uin in online else "offline"


async def tell_watchers(uin: int, status: str):
    for (owner,) in conn.execute("select owner from contacts where contact=?", (uin,)).fetchall():
        if owner in online:
            await send(online[owner][0], {"t": "presence", "uin": str(uin), "status": status})


def contact_payload(owner: int):
    rows = conn.execute("select u.uin,u.nick from contacts c join users u "
                        "on u.uin=c.contact where c.owner=?", (owner,)).fetchall()
    return [{"uin": str(u), "nick": n, "status": status_of(u)} for u, n in rows]


async def handler(ws):
    uin = None
    try:
        async for raw in ws:
            try:
                p = json.loads(raw)
                t = p.get("t")
            except (ValueError, AttributeError):
                continue

            if t == "register":
                nick, pw = str(p.get("nick", "")).strip()[:24], str(p.get("password", ""))
                if not nick or len(pw) < 4:
                    await send(ws, {"t": "error", "msg": "Need a nickname and a 4+ char password."})
                    continue
                salt = secrets.token_bytes(16)
                cur = conn.execute(
                    "insert into users(uin,nick,salt,pw) values("
                    "(select coalesce(max(uin),100000)+1 from users),?,?,?)",
                    (nick, salt, _hash(pw, salt)))
                conn.commit()
                await send(ws, {"t": "registered", "uin": str(cur.lastrowid)})

            elif t == "login":
                try:
                    n = int(p.get("uin", ""))
                except ValueError:
                    n = -1
                row = conn.execute("select nick,salt,pw from users where uin=?", (n,)).fetchone()
                if not row or not hmac.compare_digest(row[2], _hash(str(p.get("password", "")), row[1])):
                    await send(ws, {"t": "error", "msg": "Wrong UIN or password."})
                    continue
                if n in online and online[n][0] is not ws:
                    await online[n][0].close()
                uin = n
                online[uin] = (ws, "online")
                await send(ws, {"t": "login_ok", "uin": str(uin), "nick": row[0],
                                "contacts": contact_payload(uin)})
                for rid, frm, text, color, ts in conn.execute(
                        "select id,from_uin,text,color,ts from offline where to_uin=? order by id",
                        (uin,)).fetchall():
                    nick = conn.execute("select nick from users where uin=?", (frm,)).fetchone()[0]
                    await send(ws, {"t": "msg", "from": str(frm), "nick": nick,
                                    "text": text, "color": color, "ts": ts})
                conn.execute("delete from offline where to_uin=?", (uin,))
                conn.commit()
                await tell_watchers(uin, "online")

            elif uin is None:
                await send(ws, {"t": "error", "msg": "Please sign in first."})

            elif t == "status" and p.get("status") in ("online", "away", "na", "offline"):
                online[uin] = (ws, p["status"])
                await tell_watchers(uin, p["status"])

            elif t == "add":
                try:
                    target = int(p.get("uin", ""))
                except ValueError:
                    target = -1
                row = conn.execute("select nick from users where uin=?", (target,)).fetchone()
                if not row or target == uin:
                    await send(ws, {"t": "error", "msg": "No such UIN."})
                    continue
                conn.execute("insert or ignore into contacts values(?,?)", (uin, target))
                conn.commit()
                await send(ws, {"t": "contact", "uin": str(target), "nick": row[0],
                                "status": status_of(target)})

            elif t == "msg":
                try:
                    to = int(p.get("to", ""))
                except ValueError:
                    continue
                text = str(p.get("text", ""))[:4000]
                color = p.get("color", "#000000")
                color = color if COLOR_RE.match(str(color)) else "#000000"
                if not text or not conn.execute("select 1 from users where uin=?", (to,)).fetchone():
                    continue
                ts = time.time()
                me = conn.execute("select nick from users where uin=?", (uin,)).fetchone()[0]
                if to in online:
                    await send(online[to][0], {"t": "msg", "from": str(uin), "nick": me,
                                               "text": text, "color": color, "ts": ts})
                else:
                    conn.execute("insert into offline(to_uin,from_uin,text,color,ts) values(?,?,?,?,?)",
                                 (to, uin, text, color, ts))
                    conn.commit()
    finally:
        if uin and online.get(uin, (None,))[0] is ws:
            del online[uin]
            await tell_watchers(uin, "offline")


async def serve(host, port):
    async with websockets.serve(handler, host, port):
        print(f"UhOh! server listening on ws://{host}:{port}  (db: {DB_PATH})", flush=True)
        await asyncio.Future()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    a = ap.parse_args()
    init_db()
    try:
        asyncio.run(serve(a.host, a.port))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
