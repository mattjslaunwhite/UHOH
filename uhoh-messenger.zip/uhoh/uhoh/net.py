import json

from PyQt6.QtCore import QObject, QUrl, pyqtSignal
from PyQt6.QtWebSockets import QWebSocket


class Client(QObject):
    """Thin JSON-over-WebSocket client."""
    opened = pyqtSignal()
    packet = pyqtSignal(dict)
    closed = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.ws = QWebSocket()
        self._live = False
        self.ws.connected.connect(self._on_open)
        self.ws.textMessageReceived.connect(self._rx)
        self.ws.disconnected.connect(lambda: self._fail("Disconnected from server"))
        self.ws.errorOccurred.connect(lambda _e: self._fail(self.ws.errorString()))

    def open(self, url: str) -> None:
        self.ws.abort()
        self._live = True
        self.ws.open(QUrl(url))

    def close(self) -> None:
        self._live = False
        self.ws.close()

    def send(self, obj: dict) -> None:
        self.ws.sendTextMessage(json.dumps(obj))

    def _on_open(self):
        self.opened.emit()

    def _rx(self, text: str):
        try:
            self.packet.emit(json.loads(text))
        except ValueError:
            pass

    def _fail(self, why: str):
        if self._live:           # report only once per connection
            self._live = False
            self.closed.emit(why)
