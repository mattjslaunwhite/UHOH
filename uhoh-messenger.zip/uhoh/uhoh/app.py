import signal
import sys
import time

from PyQt6.QtCore import QObject, QTimer
from PyQt6.QtWidgets import (QApplication, QInputDialog, QMenu, QMessageBox,
                             QSystemTrayIcon)

from . import config, notify, sounds
from .net import Client
from .storage import Store
from .ui.chat_window import ChatWindow
from .ui.contact_list import ContactList
from .ui.login import LoginDialog
from .ui.theme import QSS, STATUS, flower


class Messenger(QObject):
    def __init__(self, app: QApplication):
        super().__init__()
        self.app = app
        self.cfg = config.load()
        sounds.enabled = self.cfg["sounds"]
        self.client = Client(self)
        self.client.opened.connect(self._on_open)
        self.client.packet.connect(self.on_packet)
        self.client.closed.connect(self.on_closed)
        self.first_packet: dict = {}
        self.password = ""
        self.uin = self.nick = ""
        self.store: Store | None = None
        self.list: ContactList | None = None
        self.tray: QSystemTrayIcon | None = None
        self.chats: dict[str, ChatWindow] = {}
        self.status = "online"

    # -- login flow ----------------------------------------------------------
    def start(self):
        dlg = LoginDialog(self.cfg)
        if not dlg.exec():
            self.quit()
            return
        v = dlg.values()
        self.cfg.update(server=v["server"], uin=v["uin"])
        config.save(self.cfg)
        self.password = v["password"]
        if v["register"]:
            self.first_packet = {"t": "register", "nick": v["nick"], "password": v["password"]}
        else:
            self.first_packet = {"t": "login", "uin": v["uin"], "password": v["password"]}
        self.client.open(v["server"])

    def _on_open(self):
        self.client.send(self.first_packet)

    def on_closed(self, why: str):
        QMessageBox.warning(None, "UhOh!", f"Connection problem:\n{why}")
        if self.list:
            self.list.hide()
            self.list = None
        QTimer.singleShot(0, self.start)

    # -- packets -------------------------------------------------------------
    def on_packet(self, p: dict):
        t = p.get("t")
        if t == "error":
            QMessageBox.warning(None, "UhOh!", p.get("msg", "Error"))
            if self.list is None:
                self.client.close()
                QTimer.singleShot(0, self.start)
        elif t == "registered":
            self.cfg["uin"] = p["uin"]
            config.save(self.cfg)
            QMessageBox.information(None, "Welcome!", f"Your new UIN is {p['uin']}.\nWrite it down!")
            self.client.send({"t": "login", "uin": p["uin"], "password": self.password})
        elif t == "login_ok":
            self._setup_main(p)
        elif self.list is None:
            return
        elif t == "presence":
            old = self.list.contacts.get(p["uin"], {}).get("status")
            self.list.upsert(p["uin"], status=p["status"])
            if old == "offline" and p["status"] != "offline":
                sounds.play("online")
        elif t == "contact":
            self.store.upsert_contact(p["uin"], p["nick"])
            self.list.upsert(p["uin"], p["nick"], p["status"])
        elif t == "msg":
            self._incoming(p)

    def _setup_main(self, p):
        self.uin, self.nick = p["uin"], p["nick"]
        self.store = Store(self.uin)
        for c in p["contacts"]:
            self.store.upsert_contact(c["uin"], c["nick"])
        self.chats.clear()
        self.list = ContactList()
        self.list.set_me(self.nick, self.uin)
        self.list.set_contacts(p["contacts"])
        self.list.open_chat.connect(self.show_chat)
        self.list.status_changed.connect(self.set_status)
        self.list.add_requested.connect(self.add_contact)
        self.list.quit_requested.connect(self.quit)
        self.list.show()
        self._setup_tray()

    def _setup_tray(self):
        if self.tray or not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(flower("online", 32), self.app)
        menu = QMenu()
        menu.addAction("Show / Hide").triggered.connect(self._toggle_list)
        for key in ("online", "away", "na", "offline"):
            menu.addAction(flower(key), STATUS[key][0]).triggered.connect(
                lambda _=False, k=key: self.set_status(k))
        menu.addSeparator()
        menu.addAction("Quit").triggered.connect(self.quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(
            lambda r: self._toggle_list() if r == QSystemTrayIcon.ActivationReason.Trigger else None)
        self.tray.setToolTip("UhOh!")
        self.tray.show()
        self._menu = menu                     # keep a reference

    def _toggle_list(self):
        if self.list:
            self.list.setVisible(not self.list.isVisible())
            if self.list.isVisible():
                self.list.raise_()
                self.list.activateWindow()

    # -- actions ------------------------------------------------------------
    def set_status(self, key: str):
        if not self.list:
            return
        self.status = key
        self.client.send({"t": "status", "status": key})
        self.list.set_my_status(key)
        if self.tray:
            self.tray.setIcon(flower(key, 32))

    def add_contact(self):
        uin, ok = QInputDialog.getText(self.list, "Add/Find Users", "Enter the UIN to add:")
        if ok and uin.strip():
            self.client.send({"t": "add", "uin": uin.strip()})

    def chat(self, uin: str) -> ChatWindow:
        if uin not in self.chats:
            nick = self.list.contacts.get(uin, {}).get("nick", uin)
            w = ChatWindow(uin, nick, self.nick, self.cfg["color"])
            w.send_requested.connect(self.send_message)
            for out, text, color, ts in self.store.history(uin):
                w.add_line(bool(out), text, color, ts)
            self.chats[uin] = w
        return self.chats[uin]

    def show_chat(self, uin: str):
        w = self.chat(uin)
        w.show()
        w.raise_()
        w.activateWindow()
        w.input.setFocus()
        self.list.set_unread(uin, False)

    def send_message(self, uin, text, color):
        self.client.send({"t": "msg", "to": uin, "text": text, "color": color})
        self.store.add_message(uin, True, text, color)
        self.chats[uin].add_line(True, text, color, time.time())
        sounds.play("sent")

    def _incoming(self, p):
        uin = p["from"]
        if uin not in self.list.contacts:
            self.client.send({"t": "add", "uin": uin})     # learn the nick
        text, color, ts = p["text"], p.get("color", "#000000"), p.get("ts", time.time())
        self.store.add_message(uin, False, text, color, ts)
        w = self.chat(uin)
        w.add_line(False, text, color, ts)
        if not (w.isVisible() and w.isActiveWindow()):
            sounds.play("uhoh")
            notify.notify(p.get("nick", uin), text)
            self.list.set_unread(uin, True)
            if not w.isVisible():
                w.show()      # classic ICQ pops the message window open

    def quit(self):
        self.client.close()
        self.app.quit()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("UhOh!")
    app.setDesktopFileName("uhoh")          # matches uhoh.desktop (Wayland app-id)
    app.setStyleSheet(QSS)
    app.setQuitOnLastWindowClosed(False)
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    m = Messenger(app)
    QTimer.singleShot(0, m.start)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
